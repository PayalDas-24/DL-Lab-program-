# Deep Learning Lab Programs

Eight Python programs prepared from the experiments in the uploaded Deep Learning Lab Manual.

## Programs
1. Word embeddings using Word2Vec
2. Deep neural network for Iris classification
3. CNN for MNIST image classification
4. Autoencoder for image compression
5. Deep learning for text document classification
6. LSTM time-series forecasting
7. Pre-trained MobileNetV2 image classification
8. Positive/negative review sentiment classification

## Notes
- These files are separated from the lab manual for convenient GitHub upload.
- Install the required Python libraries before running each program.
- TensorFlow programs may require a compatible Python/TensorFlow environment.
